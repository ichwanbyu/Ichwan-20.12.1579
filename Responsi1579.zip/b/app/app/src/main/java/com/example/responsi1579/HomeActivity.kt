package com.example.responsi1579

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

import com.example.responsi1759.R

class HomeActivity : AppCompatActivity() {
    private var layoutManager:RecyclerView.LayoutManager?=null
    private var adapter:RecyclerView.Adapter<com.example.responsi1579.ProdukAdapter.ViewHolder>?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        layoutManager= LinearLayoutManager(this)

        var rvProduk:RecyclerView= findViewById(R.id.rv_dthtl)

        rvProduk.layoutManager = layoutManager

        adapter= com.example.responsi1579.ProdukAdapter()
        rvProduk.adapter = adapter
    }
}