package com.example.responsi1579

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.responsi1579.R

class ProdukActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_produk)
    }
}