package com.example.responsi1579

import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.responsi1579.R

class ProdukAdapter:RecyclerView.Adapter<ProdukAdapter.ViewHolder>() {
    private var foto = intArrayOf(R.drawable.telaga, R.drawable.wng, R.drawable.cumbri)
    private var judul = arrayOf("Telaga Claket","Alun Giri Krida Bakti", "Bukit Cumbri")
    private var penjelasan = arrayOf(" Telaga claketLokasinya berada di Sendangijo, Selogiri. Tidak hanya refreshing atau berburu foto, Anda juga bisa memancing atau outbound di Telaga Claket. Kondisi alamnya masih terjaga dan memiliki hawa sejuk"," Giri Krida Bakti Sejak direvitalisasi pada akhir tahun 2016 yang menghabiskan anggaran kurang lebih Rp.  1 milyar menjadikan tempat ini menjadi lebih indah, rapi dan megah.  Disisi utara dibangun panggung megah dengan ornamen minimalis, bertuliskan Giri Krida Bakti. Didominasi paduan warna merah dan putih ditambah bangunan bertiang 4 buah yang kokoh.","Bukit Cumbri Ada beberapa pilihan jalur pendakian untuk menuju puncak Bukit Cumbri. Salah satu yang paling populer adalah via Pager Ukir, Kecamatan Sampung, Kabupaten Ponorogo, Jawa Timur.")

    inner class ViewHolder(itemView: View):RecyclerView.ViewHolder(itemView) {

        var itemFoto:ImageView
        var itemJudul:TextView
        var itemPenjelasan:TextView

        init {
            itemFoto = itemView.findViewById(R.id.item_foto)
            itemJudul = itemView.findViewById(R.id.item_judul)
            itemPenjelasan = itemView.findViewById(R.id.item_deskripsi)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.cardview_produk,parent,false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.itemFoto.setImageResource(foto[position])
        holder.itemPenjelasan.text = penjelasan[position]
        holder.itemJudul.text = judul[position]
    }

    override fun getItemCount(): Int {
        return judul.size
    }
}